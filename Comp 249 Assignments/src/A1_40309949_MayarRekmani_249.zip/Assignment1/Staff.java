package Assignment1;
// create a class Staff that extends Person
 class Staff extends Person {
     private String role;
     private boolean status;
     // create a constructor that has all the variables
     public Staff(String name1, String iD1, String role1, boolean status1) {
         super(name1, iD1);
         this.role = role1;
         this.status = status1;
     }
     //override role
     @Override
     public String role(){
         return("Role: "+getStatus()+" "+this.role) ;
     }
     // create getters and setters for evry variable
     public String getStatus(){
         //here we want it to return whether they are full time or part time
         if (status){
             return "Full-Time";
         }
         return ("Part-Time");
     }
     public void setStatus(boolean status1) {
         this.status = status1;
     }
     public void setRole(String role1){
         this.role = role1;
     }
     public String getRole(){
         return this.role;
     }
//override the equals method
     @Override
     public boolean equals(Person person) {
         return super.equals(person);
     }

//override the toString method
     @Override
     public String toString() {
         return ("Staff: " +super.toString()+" Role="+role+", Full-Time="+status);
     }

 }
