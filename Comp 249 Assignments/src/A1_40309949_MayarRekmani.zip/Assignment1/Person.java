package Assignment1;

 abstract class Person {
    // store name and ID as protected as it will be used in the ubclasses of Person
    protected String name;
    protected String iD;
    // create a constructor for person
    public  Person (String name1, String iD1){
        this.name = name1;
        this.iD = iD1;
    }
     // create a method that returns a textual desciption of persons role
    public String role(){
        return ("Role: ");
    }
    // override the toSTring method which will display the persons name and id
    @Override
    public String toString(){
        return ("Person[name="+name+", "+"ID="+iD+"],");
    }
    // create an equals method that compares variables to see if it is the same user

    public boolean equals(Person person){
        if (person.getClass()!=this.getClass()){
            return false;
        }
        return  person.iD.equals(this.iD);
    }
}
