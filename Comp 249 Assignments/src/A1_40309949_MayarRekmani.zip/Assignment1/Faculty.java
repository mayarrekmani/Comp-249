package Assignment1;
// create a class Faculty that extends Person
 class Faculty extends Person{
     // create variables for department and rank
     private String department;
     private String rank;
     // create a constructor that contains the variables
     public Faculty(String name, String iD, String department, String rank) {
         super(name, iD);
         this.department = department;
         this.rank = rank;
     }
     // override the role method
     @Override
     public String role(){
         return("Role: "+this.rank+" in "+this.department) ;
     }
     //create getters and setters for every variable
     public void setDepartment(String department) {
         this.department = department;
     }
     public void setRank(String rank){
         this.rank = rank;
     }
     public String getDepartment(){
         return this.department;
     }
     public String getRank(){
         return this.rank;
     }
// override the equals method
     @Override
     public boolean equals(Person person) {
         return super.equals(person);
     }
     public String facultyDifferences(Faculty faculty){
         if (!(faculty.getDepartment().equals(this.department))&&!(faculty.getRank().equals(this.rank)))
         {
             return "(Different IDs, Department and Rank";
         }
         else if (!(faculty.getDepartment().equals(this.department))) {
             return "Different ID's and Department";
         }
         else {
             return "Different ID's and Rank";
         }
     }

// override the toString method
     @Override
     public String toString() {
         return ("Faculty: " +super.toString()+" Department="+department+", Rank="+rank);
     }

 }
