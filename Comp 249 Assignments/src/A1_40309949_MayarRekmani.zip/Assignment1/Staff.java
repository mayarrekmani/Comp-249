package Assignment1;
// create a class Staff that extends Person
 class Staff extends Person {
     private String role;
     private boolean status;
     // create a constructor that has all the variables
     public Staff(String name1, String iD1, String role1, boolean status1) {
         super(name1, iD1);
         this.role = role1;
         this.status = status1;
     }
     //override role
     @Override
     public String role(){
         return("Role: "+statusFullTime()+" "+this.role) ;
     }
     // create getters and setters for evry variable
     public boolean getStatus(){
         return this.status;
     }
     public String statusFullTime(){
         if (status){
             return "Full-Time";
         }
         else{
             return "Part-Time";
         }
     }
     public void setStatus(boolean status1) {
         this.status = status1;
     }
     public void setRole(String role1){
         this.role = role1;
     }
     public String getRole(){
         return this.role;
     }
     public String staffDifferences(Staff staff){
         if (!(staff.getRole().equals(this.role))&&(staff.getStatus()!=this.status)){
             return "(Different ID's, Role and Full-Time Status)";
         } else if (!(staff.getRole().equals(this.role))) {
             return "(Different ID's and Role)";
         }
         else {
             return "(Different ID's and Full-Time Status)";
         }
     }
//override the equals method
     @Override
     public boolean equals(Person person) {
         return super.equals(person);
     }

//override the toString method
     @Override
     public String toString() {
         return ("Staff: " +super.toString()+" Role="+role+", Full-Time="+status);
     }

 }
