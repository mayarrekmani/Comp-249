package Assignment1;
// make a class Student that extends person
class Student extends Person {
    public Student(String name, String iD, double gpa, String specificFields) {
        super(name, iD);
        this.gPA = gpa;
        this.specificFields = specificFields;
    }

    // create variables for GPA and specific fields
    private double gPA;
    private String specificFields;

    // override role
    @Override
    public String role() {
        return ("Role: Undergraduate student in " + this.specificFields);
    }

    // create getters and setters for every variable
    public void setgPA(double gPA) {
        this.gPA = gPA;
    }

    public void setSpecificFields(String specificFields) {
        this.specificFields = specificFields;
    }

    public String getSpecificFields() {
        return this.specificFields;
    }

    public double getgPA() {
        return this.gPA;
    }

    //override the equals method
    @Override
    public boolean equals(Person person) {
        return super.equals(person);
    }

    public String differences(Student student) {
        if ((student.getgPA() != this.gPA) && !(student.getSpecificFields()).equals(this.specificFields)) {
            return "(Different ID's, GPA and Specific Fields)";
        } else if ((student.getgPA() != this.gPA)) {
            return "(Different ID's and GPA";
        } else {
            return "(Different ID's and Specific Fields";
        }
    }

// override the toSTring method
        @Override
        public String toString(){
            return ("Student: " + super.toString() + " GPA=" + gPA + ", Major=" + specificFields);
        }


}
