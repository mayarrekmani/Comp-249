package Assignment1;

import java.util.Objects;

// create a main
public class Main {
    public static void main(String[] args) {
        //create a variable to check if the ID is the same
        String checkID;
        //create two objects of student each with their own respective variables
        Student student1 = new Student("Dylan","S124", 3.2, "Accounting" );
        Student student2 = new Student("Joel","S125", 3.8, "Mining" );
// display both the students toString as well as their role for both people
        System.out.println(student1);
        System.out.println(student1.role());
        System.out.println();
        System.out.println(student2);
        System.out.println(student2.role());
        System.out.println();
        // bring in the equals method to see whether the students are the same and display true or false on check if
        if (student1.equals(student2)){
            checkID = "true";
        }
        else {checkID =student1.differences(student2);}
        System.out.println("Are "+student1.name+" and "+student2.name+" equal? "+ checkID);
        System.out.println();
// create two objects of faculty
        Faculty facultyMember1 = new Faculty("Dr. Seuss","F001", "English", "Professor" );
        Faculty facultyMember2 = new Faculty("Dr. Seuss","F001", "English", "Professor" );
// print both the toSTring and the roles of each proffesor
        System.out.println(facultyMember1);
        System.out.println(facultyMember1.role());
        System.out.println();
        System.out.println(facultyMember2);
        System.out.println(facultyMember2.role());
        System.out.println();
        // check whether the faculty members are the same and display the appropriate response
        if (facultyMember1.equals(facultyMember2)){
            checkID = "true";
        }
        else {checkID = facultyMember1.facultyDifferences(facultyMember2);}
        System.out.println("Are both faculty members equal? "+ checkID);
// create two objects of staff
        Staff members1 = new Staff("John","T501", "Registrar", false);
        Staff members2 = new Staff("John","T505", "Janitor", true);
// display both the toSTring and their roles
        System.out.println(members1);
        System.out.println(members1.role());
        System.out.println();
        System.out.println(members2);
        System.out.println(members2.role());
        System.out.println();
        //see whether their iDs are the same and if they are not see whether their status is the same
        if (members1.equals(members2)){
            checkID = "true";
        }
        else {
            checkID = members1.staffDifferences(members2);
        }
        System.out.println("Are two staff members equal? "+ checkID);
    }
}
