package Assignment7;

public interface DisplayableComparison extends Ordered{
     void showComparisonResult();
}
