package Assignment9;

 class InvalidInput extends Exception {
    public InvalidInput() {
        super("Must be a number between 1 and 5!");
    }
}
